income=int(input('enter monthly income'))

print(income)
if income>=100000 :
    print("premium loan")

elif income>=50000 :
    print("standard loan")

elif income>=25000 :
    print("basic loan")

else: 
    print("not eligible")