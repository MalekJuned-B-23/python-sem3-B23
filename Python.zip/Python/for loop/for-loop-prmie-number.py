n=int(input("enter no"))
cnt=0
for i in range(1,n+1):
   if(n%i==0):
       cnt+=1
print(cnt)
if(cnt==2):
         print("prime no")
else:
     
     print("not prime no")