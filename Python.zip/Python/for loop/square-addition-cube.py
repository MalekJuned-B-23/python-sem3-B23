#n
n=int(input("enter number"))
sum=0

for i in range(1,n+1):

    sum=sum+ (i**i)
print(sum)

#--output-----
#enter the number 3
#32