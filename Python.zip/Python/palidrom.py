num=int(input("enter number"))

temp=num
rev=0

while temp>0:
    re=temp%10
    rev=rev*10 +re
    
    temp//=10
    
if (num==rev):
    print(num," it is palidrom number")
else:
        print(num," it is not  palidrom number" )
    