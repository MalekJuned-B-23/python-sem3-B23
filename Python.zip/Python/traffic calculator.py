speed=int(input('enter speed'))

print(speed)
if speed<=60 :
    print("NO FINE")

elif speed<=80 :
    print("FINE 500")

elif speed<=100 :
    print("FINE 1,000")

else: 
    print("FINE 2,000 ")