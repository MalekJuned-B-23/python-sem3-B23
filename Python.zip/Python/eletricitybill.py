unit=int(input('enter the unit'))
bill_amt=int();
if unit<=100 :
    bill_amt=unit*2
elif unit<=200 :
    bill_amt(100*2)+((unit-100)*3)
elif unit<=300 :
    bill_amt(100*2)+((unit-200)*5)
else :
   bill_amt(100*2)+(100*3)+(100*4)+((unit-300)*7) 