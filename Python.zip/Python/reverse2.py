num=int(input("enter number"))

rev=0

while num>0:
    
    re=num%10
    rev=rev*10+re
    
    num//=10
    
    
    print('reverse=',rev)