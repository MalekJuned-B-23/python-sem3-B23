num=int(input("enter number"))

sum=0
temp=num

while temp>0:
    re=temp%10
    sum=sum+re**3
    
    temp//=10
    
if (num==sum):
    print(num," is armstrong number")
else:
        print(num," is not armstrong number" )
    