age=int(input('enter age'))

print(age)
if age<=5 :
    print("ticket free")

elif age<=12 :
    print("ticket 100")

elif age<=59 :
    print("ticket 200")

else: 
    print("ticket 150")

    age=int(input('enter age'))
