unit = int(input("enter the units:"))
print(unit)
if (unit <= 100):
    bill_amount=(unit*2)
elif (unit <= 200):
    bill_amount=(100*2)+(unit-100)*3
elif (unit <= 300):
    bill_amount=(100*2)+(100*3)+(unit-100)*5
elif (unit <= 400):
    bill_amount=(100*2)+(100*3)+(100*5)+(unit-100)*7
else:
    bill_amount=0
print("units:",bill_amount)