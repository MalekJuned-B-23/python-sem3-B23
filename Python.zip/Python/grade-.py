marks=int(input('enter marks'))

print(marks)
if marks>=90 :
    print("garde A ")

elif marks>=80 :
    print("grade B")

elif marks>=70 :
    print("grade C")

else: 
    print("fail ")